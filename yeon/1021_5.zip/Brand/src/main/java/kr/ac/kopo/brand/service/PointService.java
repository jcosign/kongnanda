package kr.ac.kopo.brand.service;

import java.util.List;

import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.util.Pager;

public interface PointService {


	List<Point> list(Pager pager);

	void add(Point item);

	Point item(int pointnum);

	void update(Point item);

	void delete(int pointnum);

	boolean login(Point item);

	int checkId(String id);

}
