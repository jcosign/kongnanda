package kr.ac.kopo.brand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.brand.dao.PointDao;
import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.util.Pager;

@Service
public class PointServiceImpl implements PointService {

	@Autowired
	PointDao dao;

	@Override
	public List<Point> list(Pager pager) {
		int total = dao.total(pager);

		pager.setTotal(total);

		return dao.list(pager);
	}

	@Override
	public void add(Point item) {
		dao.add(item);
	}

	@Override
	public Point item(int pointnum) {
		return dao.item(pointnum);
	}

	@Override
	public void update(Point item) {
		dao.update(item);
	}

	@Override
	public void delete(int pointnum) {
		dao.delete(pointnum);
	}

	@Override
	public boolean login(Point item) {
		Point point = dao.login(item);
		if(point == null) 
			return false;
		
		item.setPointid( point.getPointid() );
		item.setPassword(point.getPassword());
		item.setPointname(point.getPointname());
		
		return true;
	}

	@Override
	public int checkId(String id) {
		return dao.checkId(id);
	}

}
