package kr.ac.kopo.brand.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.service.PointService;
import kr.ac.kopo.brand.util.Pager;

@Controller
@RequestMapping("/point")
public class PointController {
	final String path = "point/";
	
	@Autowired
	PointService service;
	
	@GetMapping({"", "/list"})
	String list(Pager pager, Model model) {
		List<Point> list = service.list(pager);
		
		model.addAttribute("list", list);
		
		return path + "list";
	}
	
	@GetMapping("/add")
	String add() {
		return path + "add";
	}
	
	@PostMapping("/add")
	String add(Point item) {
		service.add(item);
		
		return "redirect:list";
	}
	
	@GetMapping("/{pointnum}/update")
	String update(@PathVariable int pointnum, Model model) {
		Point item = service.item(pointnum);
		
		model.addAttribute("item", item);
		
		return path + "update";
	}
	
	@PostMapping("/{pointnum}/update")
	String update(@PathVariable int pointnum, Point item) {
		service.update(item);
		
		return "redirect:../list";
	}
	
	@GetMapping("/{pointnum}/delete")
	String delete(@PathVariable int pointnum) {
		service.delete(pointnum);
		
		return "redirect:../list";
	}

}
