package kr.ac.kopo.brand.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.ac.kopo.brand.dao.DetailDao;
import kr.ac.kopo.brand.dao.OrdersDao;
import kr.ac.kopo.brand.model.Detail;
import kr.ac.kopo.brand.model.Goods;
import kr.ac.kopo.brand.model.Orders;
import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.util.Pager;

@Service
public class OrdersServiceImpl implements OrdersService {

	@Autowired
	OrdersDao dao;

	@Autowired
	DetailDao daoDetail;

	@Override
	public List<Orders> list(Pager pager) {
		int total = dao.total(pager);

		pager.setTotal(total);

		return dao.list(pager);
	}

	@Override
	public void add(Orders item) {
		dao.add(item);
	}

	@Override
	public Orders item(int orderid) {
		return dao.item(orderid);
	}

	@Override
	public void update(Orders item) {
		dao.update(item);
	}

	@Override
	public void delete(int orderid) {
		dao.delete(orderid);
	}

	@Override
	@Transactional
	public void order(Point point, Map<Integer, Goods> cart) {
		Orders item = new Orders();

		int saleprice = 0;
		for (Integer goodsid : cart.keySet()) {
			Goods goods = cart.get(goodsid);

			saleprice += goods.getPrice() * goods.getQuantity();
		}

		item.setPointnum(point.getPointnum());
		item.setSaleprice(saleprice);

		dao.add(item);

		for (Integer goodsid : cart.keySet()) {
			Goods goods = cart.get(goodsid);

			Detail detail = new Detail();

			detail.setOrderid(item.getOrderid());
			detail.setGoodsid(goods.getGoodsid());
			detail.setQuantity(goods.getQuantity());

			daoDetail.add(detail);
		}

	}

}
