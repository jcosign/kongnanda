package kr.ac.kopo.brand.service;

import java.util.List;

import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.util.Pager;

public interface PointService {


	List<Point> list(Pager pager);

	void add(Point item);

	Point item(int Pointid);

	void update(Point item);

	void delete(int Pointid);

	boolean login(Point item);

	int checkId(String id);

}
