package kr.ac.kopo.brand.dao;

import java.util.List;

import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.util.Pager;

public interface PointDao {

	int total(Pager pager);

	List<Point> list(Pager pager);

	void add(Point item);

	Point item(int pointnum);

	void update(Point item);

	void delete(int pointnum);

	Point login(Point item);

	int checkId(String id);
}
