package kr.co.kopo.dao;

import java.util.List;

import kr.co.kopo.model.Coffee;
import kr.co.kopo.util.Pager;

public interface CoffeeDao {

	List<Coffee> list(Pager pager);

	void add(Coffee item);

	void delete(int beanid);

	void update(Coffee item);

	Coffee item(int beanid);

	int total(Pager pager);

}
