package kr.co.kopo.dao;

import java.util.List;

import kr.co.kopo.model.Orders;
import kr.co.kopo.util.Pager;

public interface OrdersDao {

	int total(Pager pager);

	List<Orders> list(Pager pager);

	Orders item(int orderid);

	void add(Orders item);

	void update(Orders item);

	void delete(int orderid);

}
