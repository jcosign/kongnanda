package kr.co.kopo.dao;

import kr.co.kopo.model.Detail;

public interface DetailDao {

	void add(Detail detail);

}
