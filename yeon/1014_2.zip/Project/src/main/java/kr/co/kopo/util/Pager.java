package kr.co.kopo.util;

public class Pager {

	int page = 1;
	int perpage = 10;
	float total;
	int pergroup = 5;
	
	int search = 0;
	String keyword;
	
	int header=1;
	int order=0;
	
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getPerpage() {
		return perpage;
	}
	public void setPerpage(int perpage) {
		this.perpage = perpage;
	}
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public int getPergroup() {
		return pergroup;
	}
	public void setPergroup(int pergroup) {
		this.pergroup = pergroup;
	}
	
}
