package kr.co.kopo.service;

import java.util.List;
import java.util.Map;

import kr.co.kopo.model.Coffee;
import kr.co.kopo.model.Customer;
import kr.co.kopo.model.Orders;
import kr.co.kopo.util.Pager;

public interface OrdersService {

	Orders item(int orderid);

	List<Orders> list(Pager pager);

	void add(Orders item);

	void update(Orders item);

	void delete(int orderid);

	void order(Customer customer, Map<Integer, Coffee> cart);

}
