package kr.co.kopo.service;

import java.util.List;

import kr.co.kopo.model.Customer;
import kr.co.kopo.util.Pager;

public interface CustomerService {

	int checkId(String id);

	boolean login(Customer item);

	void add(Customer item);

	List<Customer> list(Pager pager);

	Customer item(int custid);

	void update(Customer item);

	void delete(int custid);

}
