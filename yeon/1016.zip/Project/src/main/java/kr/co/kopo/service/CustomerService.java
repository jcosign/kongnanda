package kr.co.kopo.service;

import java.util.List;

import kr.co.kopo.model.Customer;
import kr.co.kopo.util.Pager;

public interface CustomerService {

	List<Customer> list(Pager pager);
	
	void add(Customer item);
	
	Customer item(int custid);
	
	void update(Customer item);
	
	void delete(int custid);
	
	boolean login(Customer item);
	
	int checkId(String id);

}
