package kr.co.kopo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.co.kopo.model.Coffee;
import kr.co.kopo.service.CoffeeService;
import kr.co.kopo.util.Pager;

@Controller
@RequestMapping("/coffee")
public class CoffeeController {
	final String path = "Coffee/";
	
	@Autowired
	CoffeeService service;
	
	@GetMapping("/list")
	String list(Model model, Pager pager) {
		System.out.println("afsdadfd");
		List<Coffee> list= service.list(pager);
		
		model.addAttribute("list", list);
		
		return path + "list";
	}
	
	@GetMapping("/add")
	String add() {
		
		return path + "add";
	}
	@PostMapping("/add")
	String add(Coffee item) {
		service.add(item);
		
		return "redirect:/list";
	}
	
	@GetMapping("/{beanid}/delete")
	String delete(@PathVariable int beanid) {
		service.delete(beanid);

		return "redirect:/list";
	}
	
	@GetMapping("/{beanid}/update")
	String update(@PathVariable int beanid, Model model) {
		Coffee item = service.item(beanid);
		
		model.addAttribute("item", item);
		
		return path + "update";
	}
	@PostMapping("/{beanid}/update")
	String update(@PathVariable int beanid, Coffee item) {
		service.update(item);
		
		return "redirect:/list";
	}
	
}
