package kr.ac.kopo.brand.dao;

import java.util.List;

import kr.ac.kopo.brand.model.Orders;
import kr.ac.kopo.brand.util.Pager;

public interface OrdersDao {

	int total(Pager pager);

	List<Orders> list(Pager pager);

	Orders item(int orderid);

	void add(Orders item);

	void update(Orders item);

	void delete(int orderid);

}
