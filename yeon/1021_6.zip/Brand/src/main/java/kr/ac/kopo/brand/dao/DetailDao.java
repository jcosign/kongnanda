package kr.ac.kopo.brand.dao;

import kr.ac.kopo.brand.model.Detail;

public interface DetailDao {
	
	void add(Detail detail);

}
