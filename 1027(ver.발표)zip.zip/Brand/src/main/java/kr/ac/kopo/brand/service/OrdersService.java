package kr.ac.kopo.brand.service;

import java.util.List;
import java.util.Map;

import kr.ac.kopo.brand.model.Goods;
import kr.ac.kopo.brand.model.Orders;
import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.util.Pager;

public interface OrdersService {

	List<Orders> list(Pager pager);

	void add(Orders item);

	Orders item(int orderid);

	void update(Orders item);

	void delete(int orderid);

	void order(Point point, Map<Integer, Goods> cart);
}
