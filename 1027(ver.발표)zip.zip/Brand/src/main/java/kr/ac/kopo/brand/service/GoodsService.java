package kr.ac.kopo.brand.service;

import java.util.List;

import kr.ac.kopo.brand.model.Goods;
import kr.ac.kopo.brand.util.Pager;

public interface GoodsService {

	List<Goods> list(Pager pager);

	void add(Goods item);

	Goods item(int goodsid);

	void update(Goods item);

	void delete(int goodsid);

	void dummy();

	void init();
}
