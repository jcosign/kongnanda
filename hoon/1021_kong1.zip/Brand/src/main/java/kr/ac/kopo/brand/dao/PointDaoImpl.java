package kr.ac.kopo.brand.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.brand.model.Point;
import kr.ac.kopo.brand.util.Pager;

@Repository
public class PointDaoImpl implements PointDao {

	@Autowired
	SqlSession sql;

	@Override
	public int total(Pager pager) {
		return sql.selectOne("point.total", pager);
	}

	@Override
	public List<Point> list(Pager pager) {
		return sql.selectList("point.list", pager);
	}

	@Override
	public void add(Point item) {
		sql.insert("point.add", item);
	}

	@Override
	public Point item(int pointnum) {
		return sql.selectOne("point.item", pointnum);
	}

	@Override
	public void update(Point item) {
		sql.update("point.update", item);
	}

	@Override
	public void delete(int pointnum) {
		sql.delete("point.delete", pointnum);
	}

	@Override
	public Point login(Point item) {
		return sql.selectOne("point.login", item);
	}

	@Override
	public int checkId(String id) {
		return sql.selectOne("point.checkid", id);
	}

}
