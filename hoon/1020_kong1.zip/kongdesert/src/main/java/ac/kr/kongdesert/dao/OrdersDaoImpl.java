package ac.kr.kongdesert.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ac.kr.kongdesert.model.Orders;

@Repository
public class OrdersDaoImpl implements OrdersDao {

	@Autowired
	SqlSession sql;
	
	@Override
	public List<Orders> list() {
		return sql.selectList("Orders.list");
	}

	@Override
	public void add(int orderid) {
		sql.insert("Orders.add", orderid);
	}

	@Override
	public Orders item(int orderid) {
		return sql.selectOne("Orders.item", orderid);
	}

	@Override
	public void update(Orders item) {
		sql.update("Orders.update", item);
	}

	@Override
	public void delete(int orderid) {
		sql.delete("Orders.delete", orderid);
	}

}
