package ac.kr.kongdesert.dao;

import java.util.List;

import ac.kr.kongdesert.model.Orders;

public interface OrdersDao {

	List<Orders> list();

	void add(int orderid);

	Orders item(int orderid);

	void update(Orders item);

	void delete(int orderid);

}
