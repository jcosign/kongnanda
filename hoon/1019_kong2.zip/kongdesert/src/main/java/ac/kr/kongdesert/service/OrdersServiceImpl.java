package ac.kr.kongdesert.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ac.kr.kongdesert.dao.OrdersDao;
import ac.kr.kongdesert.model.Orders;

@Service
public class OrdersServiceImpl implements OrdersService {

	@Autowired
	OrdersDao dao;
	
	@Override
	public List<Orders> list() {
		return dao.list();
	}

	@Override
	public void add(int orderid) {
		dao.add(orderid);
	}

	@Override
	public Orders item(int orderid) {
		return dao.item(orderid);
	}

	@Override
	public void update(Orders item) {
		dao.update(item);
	}

	@Override
	public void delete(int orderid) {
		dao.delete(orderid);
	}

}
